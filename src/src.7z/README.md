# LLM LTL trace generate

## Code List

1. simple_io.py 
2. CoT_node.py
3. CoT_tree.py
4. partial_logic_checker.py
5. requirement.txt
6. Ours.py

## Usage

1. pip install -r requirements.txt
2. save openai_api_key in /apikey
3. cd src 
4. run .py files



